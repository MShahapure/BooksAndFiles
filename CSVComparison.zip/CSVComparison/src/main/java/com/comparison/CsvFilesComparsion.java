package com.comparison;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

public class CsvFilesComparsion {
	private static final String PATH_FOR_FILE1 = "D:\\csv file\\file1.csv";
	private static final String PATH_FOR_FILE2 = "D:\\csv file\\file2.csv";
	private static final String ID="id";
	private static final String NAME="name";
	private static final String ADDRESS="address";

	public void fileComparison() throws IOException {
		BufferedReader csvReader1=null;
		BufferedReader csvReader2 =null;
		CSVParser csvParser1=null;
		CSVParser csvParser2 =null;
		
		List<PersonDetails> details1 = new ArrayList<>();
		List<PersonDetails> details2 = new ArrayList<>();
		try {
			 csvReader1 = new BufferedReader(new FileReader(PATH_FOR_FILE1));
			 csvReader2 = new BufferedReader(new FileReader(PATH_FOR_FILE2));
			 csvParser1 = new CSVParser(csvReader1,CSVFormat.DEFAULT.withHeader(ID, NAME, ADDRESS).withIgnoreHeaderCase().withTrim());
			 csvParser2 = new CSVParser(csvReader2,CSVFormat.DEFAULT.withHeader(ID, NAME, ADDRESS).withIgnoreHeaderCase().withTrim());
			for (CSVRecord csvRecord : csvParser1) {
				String id = csvRecord.get(ID);
				String name = csvRecord.get(NAME);
				String address = csvRecord.get(ADDRESS);

				PersonDetails details = new PersonDetails(id, name, address);
				details1.add(details);
			}
			for (CSVRecord csvRecord : csvParser2) {
				String id = csvRecord.get(ID);
				String name = csvRecord.get(NAME);
				String address = csvRecord.get(ADDRESS);

				PersonDetails details = new PersonDetails(id, name, address);
				details2.add(details);
			}

			printDifferenceInIdPresentCSVFiles(details1, details2);
			printChangesInIdValueCSVFiles(details1, details2);

		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			csvReader2.close();
			csvReader1.close();
			csvParser1.close();
			csvParser2.close();

		}

	}

	private void printChangesInIdValueCSVFiles(List<PersonDetails> details1, List<PersonDetails> details2) {
		List<PersonDetails> commonRecordWithRespectToFile1 = details1.stream()
				.filter(o1 -> details2.stream().anyMatch(o2 -> o2.getId().equals(o1.getId())))
				.collect(Collectors.toList());

		List<PersonDetails> commonRecordWithRespectToFile2 = details2.stream()
				.filter(o1 -> details1.stream().anyMatch(o2 -> o2.getId().equals(o1.getId())))
				.collect(Collectors.toList());

		compareTwoFileRecords(commonRecordWithRespectToFile1, commonRecordWithRespectToFile2);

	}

	private void compareTwoFileRecords(List<PersonDetails> commonRecordWithRespectToFile1,
			List<PersonDetails> commonRecordWithRespectToFile2) {
		System.out.println("\nList of all the changes found between two files:");
		System.out.println("------------------------------------------------------");

		for (int i = 0; i < commonRecordWithRespectToFile1.size(); i++) {
			if (!commonRecordWithRespectToFile1.get(i).getAddress()
					.equalsIgnoreCase(commonRecordWithRespectToFile2.get(i).getAddress())) {
				
				System.out.print("ID: "+commonRecordWithRespectToFile1.get(i).getId()+" ID: "+commonRecordWithRespectToFile2.get(i).getId()+" "
						+commonRecordWithRespectToFile1.get(i).getName() + " "
						+ commonRecordWithRespectToFile2.get(i).getName()+" "
						+commonRecordWithRespectToFile1.get(i).getAddress() + "  "
						+ commonRecordWithRespectToFile2.get(i).getAddress()+"\n");
	
				

			}
			if (!commonRecordWithRespectToFile1.get(i).getName()
					.equalsIgnoreCase(commonRecordWithRespectToFile2.get(i).getName())) {
				System.out.print("ID: "+commonRecordWithRespectToFile1.get(i).getId()+" ID: "+commonRecordWithRespectToFile2.get(i).getId()+" "
						+commonRecordWithRespectToFile1.get(i).getName() + " "
						+ commonRecordWithRespectToFile2.get(i).getName()+" "
						+commonRecordWithRespectToFile1.get(i).getAddress() + "  "
						+ commonRecordWithRespectToFile2.get(i).getAddress()+"\n");
			}

		}

	}

	public void printDifferenceInIdPresentCSVFiles(List<PersonDetails> details1, List<PersonDetails> details2) {
		List<PersonDetails> idNotAvailableInFile2 = details1.stream()
				.filter(o1 -> details2.stream().noneMatch(o2 -> o2.getId().equals(o1.getId())))
				.collect(Collectors.toList());

		List<PersonDetails> idNotAvailableInFile1 = details2.stream()
				.filter(o1 -> details1.stream().noneMatch(o2 -> o2.getId().equals(o1.getId())))
				.collect(Collectors.toList());

		printInPlainEnglishForIdNotFound(idNotAvailableInFile2, idNotAvailableInFile1);

	}

	private void printInPlainEnglishForIdNotFound(List<PersonDetails> IdNotAvailableInFile2,List<PersonDetails> IdNotAvailableInFile1) {
		if(!IdNotAvailableInFile1.isEmpty()) {
			System.out.println("Below records are missing in File1:");
			for (@SuppressWarnings("rawtypes")
			Iterator iterator = IdNotAvailableInFile1.iterator(); iterator.hasNext();) {
				PersonDetails personDetails = (PersonDetails) iterator.next();
				System.out.println("Personal Details: "+personDetails.getId() + " " + personDetails.getName() + " " + personDetails.getAddress());

			}
		}else {
			System.out.println("No Records are missing in File1 ");
		}
		if(!IdNotAvailableInFile1.isEmpty()) {
			System.out.println("\nBelow records are missing in File2:");
			for (@SuppressWarnings("rawtypes")
			
			Iterator iterator = IdNotAvailableInFile2.iterator(); iterator.hasNext();) {
				PersonDetails personDetails = (PersonDetails) iterator.next();
				System.out.println("Personal Details: "+personDetails.getId() + " " + personDetails.getName() + " " + personDetails.getAddress());

			}
		}else {
			System.out.println("No Records are missing in File2 ");
		}
		
		

	}

}

package com.comparison;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;

import com.opencsv.CSVReader;

public class FileComparisonClass {
	private static final String PATH_FOR_FILE1 = "D:\\csv file\\file1.csv";
	private static final String PATH_FOR_FILE2 = "D:\\csv file\\file2.csv";

	public void fileComparison() throws IOException {
		BufferedReader csvReader1 = new BufferedReader(new FileReader(PATH_FOR_FILE1));
		BufferedReader csvReader2 = new BufferedReader(new FileReader(PATH_FOR_FILE2));
		
		try {
			

			String lineFile1 = csvReader1.readLine();
			String lineFile2 = csvReader2.readLine();

			boolean areEqual = true;

			int lineNum = 1;

			while (lineFile1 != null || lineFile2 != null) {
				if (lineFile1 == null || lineFile2 == null) {
					areEqual = false;

					printDifferenceInCSVFiles(lineFile1, lineFile2, lineNum);
				} else if (!lineFile1.equalsIgnoreCase(lineFile2)) {
					areEqual = false;
					printDifferenceInCSVFiles(lineFile1, lineFile2, lineNum);

				}

				lineFile1 = csvReader1.readLine();
				lineFile2 = csvReader2.readLine();
				lineNum++;
			}

		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			csvReader2.close();

			csvReader1.close();
			
			
		}

	}

	public void printDifferenceInCSVFiles(String lineFile1, String lineFile2, int lineNum) {

		System.out.println("File1 has " + lineFile1 + " where as the File2 has " + lineFile2 + " at line " + lineNum);
		String[] arr1 = lineFile1.split(",");
		String[] arr2 = lineFile2.split(",");
		for(int i=0;i<arr1.length;i++) {
		
			if(!arr1[i].equals(arr2[i])) {
				System.out.println("File1 is missing id: "+arr2[i] +" and "+"File2 is missing id: "+arr1[i] );
				
			}
		}
		
		

	}

}

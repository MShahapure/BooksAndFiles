package com.comparison;

public class PersonDetails{
	private String id;
	private String name;
	private String address;
	public PersonDetails(String id, String name, String address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	@Override
    public boolean equals(Object obj)
    {
        boolean isEqual = false;
        if (this.getClass() == obj.getClass())
        {
        	PersonDetails myValueObject = (PersonDetails) obj;
            if ((myValueObject.id).equals(this.id) &&
                    (myValueObject.address).equals(this.address)&&(myValueObject.name).equals(this.name))
            {
                isEqual = true;
            }
        }

        return isEqual;
    }
	@Override
	public String toString() {
		return "PersonDetails [id=" + id + ", name=" + name + ", address=" + address + "]";
	}
	
	
	

	
}

package com.comparison;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class MissingRecordsHTML {
	private static final String TABLE_COL="</td><td>";
	private static final String DIV="</div>";

	public void createHtml(List<PersonDetails> list, String fileName) throws IOException {
		StringBuilder buf = new StringBuilder();
		buf.append("<table border='1'>" + "<tr>" + "<th>Id</th>" + "<th>Name</th>" + "<th>Address</th>" +"<th>Missing Records</th>" + "</tr>");
		for (int i = 0; i < list.size(); i++) {
				buf.append("<tr><td>").append(list.get(i).getId());
				buf.append(TABLE_COL);
				buf.append(list.get(i).getName());
				buf.append(TABLE_COL);
				buf.append(list.get(i).getAddress());
				buf.append(TABLE_COL);
				
				if(list.get(i).getFile().equalsIgnoreCase("file1"))
					buf.append("Record is missing in File1");
				else
					buf.append("Record is missing in File2");
					
				
				
	
			buf.append("</td></tr>");

		}
		buf.append("</table>" + "</body>" + "</html>");

		writeToFile(buf.toString(), fileName+".htm");

	}
	private void writeToFile(String fileContent, String fileName) throws IOException {
		String projectPath = System.getProperty("user.dir");
		String tempFile = projectPath + File.separator + fileName;
		File file = new File(tempFile);
		Path path=Paths.get(tempFile);
		Files.deleteIfExists(path);
		boolean createNewFile = file.createNewFile();
		if(createNewFile) {
			OutputStream outputStream = new FileOutputStream(file.getAbsoluteFile());
			Writer writer = new OutputStreamWriter(outputStream);
			writer.write(fileContent);
			writer.close();

		}
	}

}

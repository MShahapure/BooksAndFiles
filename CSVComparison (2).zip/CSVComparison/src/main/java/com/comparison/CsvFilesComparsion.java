package com.comparison;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import ch.qos.logback.core.db.dialect.MsSQLDialect;

public class CsvFilesComparsion {
	private static final String PATH_FOR_FILE1 = "D:\\csv file\\file1.csv";
	private static final String PATH_FOR_FILE2 = "D:\\csv file\\file2.csv";
	private static final String ID = "id";
	private static final String NAME = "name";
	private static final String ADDRESS = "address";

	public void fileComparison() throws IOException {
		BufferedReader csvReader1 = null;
		BufferedReader csvReader2 = null;
		CSVParser csvParser1 = null;
		CSVParser csvParser2 = null;

		List<PersonDetails> details1 = new ArrayList<>();
		List<PersonDetails> details2 = new ArrayList<>();
		try {
			csvReader1 = new BufferedReader(new FileReader(PATH_FOR_FILE1));
			csvReader2 = new BufferedReader(new FileReader(PATH_FOR_FILE2));
			csvParser1 = new CSVParser(csvReader1,
					CSVFormat.DEFAULT.withHeader(ID, NAME, ADDRESS).withIgnoreHeaderCase().withTrim());
			csvParser2 = new CSVParser(csvReader2,
					CSVFormat.DEFAULT.withHeader(ID, NAME, ADDRESS).withIgnoreHeaderCase().withTrim());
			for (CSVRecord csvRecord : csvParser1) {
				String id = csvRecord.get(ID);
				String name = csvRecord.get(NAME);
				String address = csvRecord.get(ADDRESS);

				PersonDetails details = new PersonDetails(id, name, address);
				details1.add(details);
			}
			for (CSVRecord csvRecord : csvParser2) {
				String id = csvRecord.get(ID);
				String name = csvRecord.get(NAME);
				String address = csvRecord.get(ADDRESS);

				PersonDetails details = new PersonDetails(id, name, address);
				details2.add(details);
			}

			printDifferenceInIdPresentCSVFiles(details1, details2);
			printChangesInIdValueCSVFiles(details1, details2);

		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			csvReader2.close();
			csvReader1.close();
			csvParser1.close();
			csvParser2.close();

		}

	}

	private void printChangesInIdValueCSVFiles(List<PersonDetails> details1, List<PersonDetails> details2)
			throws IOException {
		List<PersonDetails> finalList = new ArrayList<>();
		for (PersonDetails o1 : details1) {
			for (PersonDetails o2 : details2) {
				PersonDetails details = new PersonDetails();
				if (o1.getId().equals(o2.getId())) {
					details.setId(o1.getId());
					if (o1.getAddress().equals(o2.getAddress()))
						details.setAddress(o1.getAddress());
					else
						details.setAddress(o1.getAddress() + ":" + o2.getAddress());
					if (o1.getName().equals(o2.getName()))
						details.setName(o2.getName());
					else
						details.setName(o1.getName() + "-" + o2.getName());

					finalList.add(details);
				}
			}
		}
		new CreateHtml().createHtml(finalList, "FileDiffernceHTML");

	}

	public void printDifferenceInIdPresentCSVFiles(List<PersonDetails> details1, List<PersonDetails> details2)
			throws IOException {
		List<PersonDetails> idNotAvailableInFile2 = details1.stream()
				.filter(o1 -> details2.stream().noneMatch(o2 -> o2.getId().equals(o1.getId())))
				.map(o -> new PersonDetails(o.getId(), o.getName(), o.getAddress(),"FILE2"))
				.collect(Collectors.toList());
		List<PersonDetails> idNotAvailableInFile1 = details2.stream()
				.filter(o1 -> details1.stream().noneMatch(o2 -> o2.getId().equals(o1.getId())))
				.map(o -> new PersonDetails(o.getId(), o.getName(), o.getAddress(), "FILE1"))
				.collect(Collectors.toList());
		idNotAvailableInFile1.addAll(idNotAvailableInFile2);
		new MissingRecordsHTML().createHtml(idNotAvailableInFile1, "MissingRecordsHTML");

	}

}
